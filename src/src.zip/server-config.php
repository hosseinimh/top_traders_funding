<?php

define('BASE_URL', 'http://toptradersfunding.com');
define('PUBLIC_PATH', __DIR__ . '/../public_html');
define('FRAMEWORK_PATH', __DIR__);
