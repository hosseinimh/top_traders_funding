<?php

require_once __DIR__ . '/Helper/MessageHelper.php';

return [
    'user_forgot_password_subject' => 'تعیین کلمه عبور جدید',
];
