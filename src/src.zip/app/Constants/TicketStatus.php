<?php

namespace App\Constants;

abstract class TicketStatus
{
    const OPEN = 1;    // باز
    const CLOSED = 2;    // تکمیل شده
}
