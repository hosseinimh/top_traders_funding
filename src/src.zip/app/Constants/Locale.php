<?php

namespace App\Constants;

abstract class Locale
{
    const EN = 'en';
    const FA = 'fa';
}
