<?php

namespace App\Constants;

abstract class StoragePath
{
    const USER_THUMBNAIL = 'public/storage/users/thumbnails';
    const TICKET_THREAD_FILE = 'public/storage/ticket_threads';
}
