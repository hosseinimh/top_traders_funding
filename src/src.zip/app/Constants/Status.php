<?php

namespace App\Constants;

abstract class Status
{
    const NOT_ACTIVE = 0;
    const ACTIVE = 1;
}
