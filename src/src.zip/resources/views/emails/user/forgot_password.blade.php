<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keyword" content="">
    <title>Top Traders Funding</title>
    <link href="http://127.0.0.1:8000/assets/css/style.css?v=c585b8" rel="stylesheet">
</head>

<body>
    <div id="root">{{$code}}</div>
    <script src="/assets/js/index.js?v=c1f2cc"></script>
</body>

</html>