export const TICKET_TYPES = {
    TYPE1: 1,
    TYPE2: 2,
    TYPE3: 3,
    TYPE4: 4,
    TYPE5: 5,
};
