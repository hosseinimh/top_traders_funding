import * as fa from "./fa";
import * as en from "./en";

export { fa, en };
