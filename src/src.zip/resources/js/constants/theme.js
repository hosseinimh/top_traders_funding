const BASE_PATH = `/panel`;
const ASSETS_PATH = "/assets";
const IMAGES_PATH = "/assets/images";
const STORAGE_PATH = "/storage";
const PAGE_ITEMS = 10;

export { BASE_PATH, ASSETS_PATH, IMAGES_PATH, STORAGE_PATH, PAGE_ITEMS };
