export const TICKET_STATUSES = {
    OPEN: 1,
    CLOSED: 2,
};
