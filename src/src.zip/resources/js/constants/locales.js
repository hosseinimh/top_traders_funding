export const LOCALES = {
    EN: "en",
    FA: "fa",
};
