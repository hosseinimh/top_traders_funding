export const USER_ROLES = {
    USER: 1,
    ADMINISTRATOR: 2,
};
