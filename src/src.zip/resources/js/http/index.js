import { get, post } from "./http";

export { get, post };
