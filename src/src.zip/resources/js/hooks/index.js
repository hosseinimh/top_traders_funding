import useLocale from "./useLocale";
import useLSLocale from "./useLSLocale";

export { useLocale, useLSLocale };
